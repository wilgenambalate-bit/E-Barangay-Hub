E-BARANGAY HUB — GITHUB + FIREBASE VERSION (MANUAL EMAIL)

WHAT THIS VERSION DOES
- Keeps the uploaded original HTML design and embedded barangay seal.
- Residents submit requests/complaints into the existing Cloud Firestore collection: submissions.
- Includes existing browser-side anti-spam checks from the supplied HTML: honeypot, minimum fill time, local cooldown/hour/day limits, duplicate fingerprint check, input validation and spam filtering.
- Admin sign-in uses Firebase Authentication (Email/Password).
- Only an authenticated admin whose admins/{UID} document has active: true can read submissions or update allowed fields.
- Admin writes a reply in the dashboard. Clicking “Save Reply & Open Gmail Draft” saves the reply/status to Firestore and opens Gmail compose addressed to the resident.
- The administrator manually reviews the email, attaches the requested/approved document in Gmail, and clicks Send.
- NO automatic email sending, NO Cloud Functions, NO Gmail App Password, NO command prompt required for the intended GitHub/Firebase Hosting workflow.

IMPORTANT EMAIL LIMITATION
The browser can open a Gmail compose draft but cannot attach a local file automatically or send it. Attach the PDF/document manually in Gmail before sending. This keeps Gmail credentials out of the website.

FILES
- public/index.html: complete website.
- firestore.rules: Firestore security rules.
- firebase.json: Hosting uses the public folder; includes Firestore rules configuration.
- .firebaserc: Firebase project alias.

FIREBASE SETUP (CONSOLE)
1. Open Firebase Console and choose project e---barangay---hub.
2. Authentication > Sign-in method > enable Email/Password.
3. Create the administrator user in Authentication > Users.
4. Copy the admin user's UID.
5. Firestore Database > Data > create collection admins, document ID exactly equal to the admin UID, field active with type Boolean and value true.
6. Firestore Database > Rules: publish the supplied firestore.rules contents.
7. Do not create a public read rule. Residents can create valid submissions, but cannot read submissions.

GITHUB UPLOAD WITHOUT CMD
1. Open https://github.com/wilgenambalate-bit/E-Barangay-Hub
2. Use Add file > Upload files.
3. Upload the contents of this package, preserving folders. Ensure public/index.html is in the public folder at repository root, alongside firebase.json and firestore.rules.
4. Commit changes to the main branch.

FIREBASE HOSTING CONNECT TO GITHUB (NO CMD)
1. In Firebase Console choose e---barangay---hub > Hosting.
2. If Hosting is already initialized, open the GitHub/continuous deployment setup option (wording may be “Set up GitHub Action” or “Connect to GitHub”). If it is not shown, use Hosting > Get started and select GitHub integration.
3. Authorize Firebase to access the repository wilgenambalate-bit/E-Barangay-Hub.
4. Select the main branch. Keep the repository root as the project directory because firebase.json is at the root and specifies public as Hosting's public directory.
5. Complete the setup and allow Firebase to create its GitHub Actions workflow.
6. After the workflow is created, future commits to main should trigger Hosting deployment. Check GitHub > Actions for success and Firebase Console > Hosting for the deployed URL.

MANUAL EMAIL WORKFLOW
1. Sign in to the Admin Panel.
2. Open a resident submission and read the provided email address and request.
3. Write the official response and select the appropriate status.
4. Click “Save Reply & Open Gmail Draft”. The response/status are saved in Firestore and Gmail opens with the resident address, subject and reply prefilled.
5. Attach the approved document manually in Gmail, verify the recipient and attachment, then click Send yourself.

SECURITY NOTES
- Never publish Gmail passwords, App Passwords, service-account JSON, or private keys in GitHub or HTML.
- The anti-spam checks inside a browser are helpful deterrents, not a complete defense against bots. Stronger abuse prevention requires server-side controls and/or App Check configuration.
- Review document contents and recipient email carefully before sending sensitive barangay records.
- Firestore rules cannot stop all abuse of public create access; monitor usage and configure App Check when ready.
